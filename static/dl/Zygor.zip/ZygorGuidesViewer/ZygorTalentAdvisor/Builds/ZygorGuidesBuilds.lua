if not ZygorTalentAdvisor then return end

local ZTA=ZygorTalentAdvisor

--***Example*** Remove all the --
--Capitalization and spelling matters.
--ZTA:RegisterBuild("CLASS","Name","Spec", [[
--	Talent Tier 1
--	Talent Tier 2
--	Talent Tier 3
--	Talent Tier 4
--	Talent Tier 5
--	Talent Tier 6
--]],[[
--	Major Glyph of 1
--	Major Glyph of 2
--	Major Glyph of 3
--	Minor Glyph of 1
--	Minor Glyph of 2
--	Minor Glyph of 3
--]],"PetSpec") --PetSpec only needed if you are a HUNTER

ZTA:RegisterBuild("DEATHKNIGHT","Leveling Blood(Recommended)","Blood", {1,2,3,2,2,2,1},[[
	Major Glyph of Blood Boil
	Major Glyph of Regenerative Magic
	Major Glyph of Outbreak
	Minor Glyph of Resilient Grip
	Minor Glyph of Army of the Dead
	Minor Glyph of Path of Frost
]])
ZTA:RegisterBuild("DEATHKNIGHT","Leveling Frost","Frost", {3,2,3,3,1,2,1},[[
	Major Glyph of Blood Boil
	Major Glyph of Strangulate
	Major Glyph of Regenerative Magic
	Minor Glyph of Resilient Grip
	Minor Glyph of Army of the Dead
	Minor Glyph of Path of Frost
]])
ZTA:RegisterBuild("DEATHKNIGHT","Leveling Unholy","Unholy", {3,2,3,3,2,2,2},[[
	Major Glyph of Blood Boil
	Major Glyph of Raise Ally
	Major Glyph of Regenerative Magic
	Minor Glyph of Resilient Grip
	Minor Glyph of Death's Embrace
	Minor Glyph of Path of Frost
]])
ZTA:RegisterBuild("PRIEST","Leveling Shadow(Recommended)","Shadow", {1,1,2,1,2,3,1},[[
	Major Glyph of Mind Harvest
	Major Glyph of Mind Flay
	Major Glyph of Mass Dispel
	Minor Glyph of Dark Archangel
	Minor Glyph of Shadow Ravens
	Minor Glyph of Shadowy Friends
]])
ZTA:RegisterBuild("PRIEST","Leveling Discipline","Discipline", {1,1,3,1,3,1,3},[[
	Major Glyph of Holy Fire
	Major Glyph of Penance
	Major Glyph of Weakened Soul
	Minor Glyph of Borrowed Time
	Minor Glyph of Holy Resurrection
	Minor Glyph of Confession
]])
ZTA:RegisterBuild("PRIEST","Leveling Holy","Holy", {1,1,2,1,2,2,3},[[
	Major Glyph of Renew
	Major Glyph of Circle of Healing
	Major Glyph of Binding Heal
	Minor Glyph of Heavens
	Minor Glyph of Holy Resurrection
	Minor Glyph of Confession
]])
ZTA:RegisterBuild("MAGE","Leveling Fire","Fire", {3,1,1,1,1,2,2},[[
	Major Glyph of Combustion
	Major Glyph of Inferno Blast
	Major Glyph of Dragon's Breath
	Minor Glyph of Momentum
	Minor Glyph of Arcane Language
	Minor Glyph of Conjure Familiar
]])
ZTA:RegisterBuild("MAGE","Leveling Frost(Recommended)","Frost", {3,1,1,3,1,2,2},[[
	Major Glyph of Splitting Ice
	Major Glyph of Icy Veins
	Major Glyph of Water Elemental
	Minor Glyph of Momentum
	Minor Glyph of Arcane Language
	Minor Glyph of Conjure Familiar
]])
ZTA:RegisterBuild("MAGE","Leveling Arcane","Arcane", {3,1,1,1,1,2,3},[[
	Major Glyph of Cone of Cold
	Major Glyph of Arcane Power
	Major Glyph of Slow
	Minor Glyph of Momentum
	Minor Glyph of Conjure Familiar
	Minor Glyph of Arcane Language
]])
ZTA:RegisterBuild("WARRIOR","Leveling Arms(Recommended)","Arms", {2,1,2,1,3,2,2},[[
	Major Glyph of Bull Rush
	Major Glyph of Death From Above
	Major Glyph of Sweeping Strikes
	Minor Glyph of Subtle Defender
	Minor Glyph of Thunder Strike
	Minor Glyph of Intimidating Shout
]])
ZTA:RegisterBuild("WARRIOR","Leveling Fury","Fury", {2,1,2,1,3,2,2},[[
	Major Glyph of Bull Rush
	Major Glyph of Death From Above
	Major Glyph of Unending Rage
	Minor Glyph of Subtle Defender
	Minor Glyph of Burning Anger
	Minor Glyph of Intimidating Shout
]])
ZTA:RegisterBuild("WARRIOR","Leveling Protection","Protection", {2,1,1,3,1,1,3},[[
	Major Glyph of Bull Rush
	Major Glyph of Rude Interruption
	Major Glyph of Blitz
	Minor Glyph of Intimidating Shout
	Minor Glyph of Bloody Healing
	Minor Glyph of Blazing Trail
]])
ZTA:RegisterBuild("DRUID","Leveling Feral(Recommended)","Feral", {2,1,2,1,3,3,2},[[
	Major Glyph of Cat Form
	Major Glyph of Ferocious Bite
	Major Glyph of Dash
	Minor Glyph of Grace
	Minor Glyph of Aquatic Form
	Minor Glyph of The Predator
]])
ZTA:RegisterBuild("DRUID","Leveling Guardian","Guardian", {3,1,3,2,3,2,2},[[
	Major Glyph of Survival Instincts
	Major Glyph of Maul
	Major Glyph of Stampeding Roar
	Minor Glyph of Grace
	Minor Glyph of The Chameleon
	Minor Glyph of Aquatic Form
]])
ZTA:RegisterBuild("DRUID","Leveling Balance","Balance", {3,1,3,1,1,3,2},[[
	Major Glyph of Astral Communion
	Major Glyph of Enchanted Bark
	Major Glyph of Stampeding Roar
	Minor Glyph of Grace
	Minor Glyph of Stars
	Minor Glyph of Aquatic Form
]])
ZTA:RegisterBuild("DRUID","Leveling Restoration","Restoration", {3,3,3,2,2,1,2},[[
	Major Glyph of Healing Touch
	Major Glyph of Wild Growth
	Major Glyph of Regrowth
	Minor Glyph of Grace
	Minor Glyph of Sprouting Mushroom
	Minor Glyph of Aquatic Form
]])
ZTA:RegisterBuild("SHAMAN","Leveling Elemental","Elemental", {2,2,3,3,2,2,1},[[
	Major Glyph of Flame Shock
	Major Glyph of Ghost Wolf
	Major Glyph of Thunder
	Minor Glyph of Thunderstorm
	Minor Glyph of Astral Recall
	Minor Glyph of Lakestrider
]])
ZTA:RegisterBuild("SHAMAN","Leveling Enhancement(Recommended)","Enhancement", {3,1,3,1,3,2,1},[[
	Major Glyph of Frost Shock
	Major Glyph of Feral Spirit
	Major Glyph of Fire Elemental Totem
	Minor Glyph of Lava Lash
	Minor Glyph of Astral Recall
	Minor Glyph of Lakestrider
]])
ZTA:RegisterBuild("SHAMAN","Leveling Restoration","Restoration", {3,1,3,2,1,2,1},[[
	Major Glyph of Healing Stream Totem
	Major Glyph of Spiritwalker's Grace
	Major Glyph of Healing Wave
	Minor Glyph of Ghostly Speed
	Minor Glyph of Astral Recall
	Minor Glyph of Lakestrider
]])
ZTA:RegisterBuild("HUNTER","Leveling Beast Mastery(Recommended)","Beast Mastery", {3,3,1,2,3,1,3},[[
	Major Glyph of Animal Bond
	Major Glyph of Deterrence
	Major Glyph of Endless Wrath
	Minor Glyph of Play Dead
	Minor Glyph of Aspect of the Cheetah
	Minor Glyph of Tame Beast
]],"Ferocity")
ZTA:RegisterBuild("HUNTER","Leveling Marksmanship","Marksmanship", {3,3,2,3,1,1,1},[[
	Major Glyph of Animal Bond
	Major Glyph of Chimaera Shot
	Major Glyph of Deterrence
	Minor Glyph of Play Dead
	Minor Glyph of Aspect of the Cheetah
	Minor Glyph of Tame Beast
]],"Tenacity")
ZTA:RegisterBuild("HUNTER","Leveling Survival","Survival", {3,3,2,3,1,1,1},[[
	Major Glyph of Animal Bond
	Major Glyph of Deterrence
	Major Glyph of Liberation
	Minor Glyph of Play Dead
	Minor Glyph of Aspect of the Cheetah
	Minor Glyph of Tame Beast
]],"Tenacity")
ZTA:RegisterBuild("MONK","Leveling Brewmaster","Brewmaster", {2,1,3,3,2,2,2},[[
	Major Glyph of Expel Harm
	Major Glyph of Keg Smash
	Major Glyph of Fortifying Brew
	Minor Glyph of Spirit Roll
	Minor Glyph of Water Roll
	Minor Glyph of Zen Flight
]])
ZTA:RegisterBuild("MONK","Leveling Mistweaver","Mistweaver", {1,1,3,1,3,2,2},[[
	Major Glyph of Surging Mist
	Major Glyph of Renewing Mist
	Major Glyph of Soothing Mist
	Minor Glyph of Water Roll
	Minor Glyph of Spirit Roll
	Minor Glyph of Zen Flight
]])
ZTA:RegisterBuild("MONK","Leveling Windwalker(Recommended)","Windwalker", {3,1,2,3,3,2,3},[[
	Major Glyph of Floating Butterfly
	Major Glyph of Zen Meditation
	Major Glyph of Touch of Karma
	Minor Glyph of Water Roll
	Minor Glyph of Blackout Kick
	Minor Glyph of Zen Flight
]])
ZTA:RegisterBuild("WARLOCK","Leveling Demonology(Recommended)","Demonology", {2,3,2,2,1,1,1},[[
	Major Glyph of Imp Swarm
	Major Glyph of Demon Training
	Major Glyph of Dark Soul
	Minor Glyph of Hand of Gul'dan
	Minor Glyph of Health Funnel
	Minor Glyph of Nightmares
]])
ZTA:RegisterBuild("WARLOCK","Leveling Destruction","Destruction", {2,3,3,2,3,1,1},[[
	Major Glyph of Healthstone
	Major Glyph of Conflagrate
	Major Glyph of Eternal Resolve
	Minor Glyph of Soulwell
	Minor Glyph of Crimson Banish
	Minor Glyph of Nightmares
]])
ZTA:RegisterBuild("WARLOCK","Leveling Affliction","Affliction", {2,3,3,2,3,1,1},[[
	Major Glyph of Life Tap
	Major Glyph of Eternal Resolve
	Major Glyph of Siphon Life
	Minor Glyph of Verdant Spheres
	Minor Glyph of Soulwell
	Minor Glyph of Nightmares
]])
ZTA:RegisterBuild("ROGUE","Leveling Assassination","Assassination", {2,2,2,3,1,1,2},[[
	Major Glyph of Vendetta
	Major Glyph of Energy
	Major Glyph of Cloak of Shadows
	Minor Glyph of Blurred Speed
	Minor Glyph of Safe Fall
	Minor Glyph of Poisons
]])
ZTA:RegisterBuild("ROGUE","Leveling Combat(Recommended)","Combat", {2,3,2,2,1,3,2},[[
	Major Glyph of Energy
	Major Glyph of Cloak of Shadows
	Major Glyph of Disappearance
	Minor Glyph of Blurred Speed
	Minor Glyph of Safe Fall
	Minor Glyph of Poisons
]])
ZTA:RegisterBuild("ROGUE","Leveling Subtlety","Subtlety", {1,3,2,2,3,3,2},[[
	Major Glyph of Hemorrhaging Veins
	Major Glyph of Vanish
	Major Glyph of Energy
	Minor Glyph of Blurred Speed
	Minor Glyph of Safe Fall
	Minor Glyph of Poisons
]])
ZTA:RegisterBuild("PALADIN","Leveling Holy","Holy", {3,2,2,3,3,2,1},[[
	Major Glyph of Merciful Wrath
	Major Glyph of Divinity
	Major Glyph of Hand of Sacrifice
	Minor Glyph of Winged Vengeance
	Minor Glyph of Contemplation
	Minor Glyph of Righteous Retreat
]])
ZTA:RegisterBuild("PALADIN","Leveling Protection","Protection", {2,1,2,1,1,1,3},[[
	Major Glyph of Focused Shield
	Major Glyph of Final Wrath
	Major Glyph of Word of Glory
	Minor Glyph of Focused Wrath
	Minor Glyph of Righteous Retreat
	Minor Glyph of Seal of Blood
]])
ZTA:RegisterBuild("PALADIN","Leveling Retribution(Recommended)","Retribution", {1,1,1,2,3,3,1},[[
	Major Glyph of Double Jeopardy
	Major Glyph of Hand of Sacrifice
	Major Glyph of Templar's Verdict
	Minor Glyph of Bladed Judgment
	Minor Glyph of Righteous Retreat
	Minor Glyph of Fire From the Heavens
]])