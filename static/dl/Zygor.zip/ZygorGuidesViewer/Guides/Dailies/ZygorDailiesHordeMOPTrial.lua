local ZygorGuidesViewer=ZygorGuidesViewer
if not ZygorGuidesViewer then return end
if UnitFactionGroup("player")~="Horde" then return end
if ZGV:DoMutex("DailiesHMOP") then return end
ZygorGuidesViewer.GuideMenuTier = "TRI"
ZygorGuidesViewer:RegisterGuide("Zygor's Horde Dailies Guides\\Pandaria (85 - 90)\\The Anglers Dailies",[[
description This guide will take you through The Anglers dailies
description Becoming Exalted with The Anglers allows you to purchase a companion pet, fishing poles, and water mounts.
startlevel 90
#include "H_Anglers"
]])
