local ZygorGuidesViewer=ZygorGuidesViewer
if not ZygorGuidesViewer then return end
if ZGV:DoMutex("CGear") then return end
if not ZGV.CommonGear then return end
if not (ZygorGuidesViewer.ItemScore and ZygorGuidesViewer.ItemScore.Items) then return end
