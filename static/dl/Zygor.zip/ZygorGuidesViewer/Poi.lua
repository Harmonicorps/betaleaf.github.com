local ZGV = ZygorGuidesViewer
if not ZGV then return end

local FONT = ZGV.Font
local CHAIN = ZGV.ChainCall
local L=ZGV.L

local Poi = {}
ZGV.Poi = Poi
ZGV.Poi.Guide = nil
ZGV.Poi.AnnounceSteps = {}
ZGV.Poi.AnnounceSteps[1] = {}
ZGV.Poi.AnnounceSteps[2] = {}
ZGV.Poi.ActivePoiStepNum = -1

local ANNOUNCE_POI_FIELDS = {poi_treasure=1,poi_rare=1,poicurrency=1,poiitem=1,poiname=1,poiaccess=1} -- skip those
local FULLSTEP_POI_FIELDS = {poicurrency=1,poiitem=1} -- show those

local ITEM_LEVEL_FILTER = string.gsub(ITEM_LEVEL,"%%d","(.*)")
local ITEM_MIN_LEVEL_FILTER = string.gsub(ITEM_MIN_LEVEL,"%%d","(.*)")
local ITEM_SLOTS_ARRAY = {INVTYPE_2HWEAPON, INVTYPE_AMMO, INVTYPE_BAG, INVTYPE_BODY, INVTYPE_CHEST, INVTYPE_CLOAK, INVTYPE_FEET, INVTYPE_FINGER, INVTYPE_HAND, INVTYPE_HEAD, INVTYPE_HOLDABLE, INVTYPE_LEGS, INVTYPE_NECK, INVTYPE_QUIVER, INVTYPE_RANGED, INVTYPE_RANGEDRIGHT, INVTYPE_RELIC, INVTYPE_ROBE, INVTYPE_SHIELD, INVTYPE_SHOULDER, INVTYPE_TABARD, INVTYPE_THROWN, INVTYPE_TRINKET, INVTYPE_WAIST, INVTYPE_WEAPON, INVTYPE_WEAPONMAINHAND, INVTYPE_WEAPONMAINHAND_PET, INVTYPE_WEAPONOFFHAND, INVTYPE_WRIST}

local POI_TYPES = {
	[1] = {keyword="achievement",display="Achievements"},
	[2] = {keyword="battlepet",display="Battle pets"},
	[3] = {keyword="rare",display="Rares"},
	[4] = {keyword="treasure",display="Treasures"},
	}

Poi.OwnedTypes = {}

function Poi:RegisterPoiGuide()
	if not ZGV.db.profile.poienabled then return end

	ZGV.GuideMenuTier = "WOD"
	Poi.Guide = ZGV.GuideProto:New("MISC\\Points of interest","",extra)
	if not Poi.Guide then return end -- we failed to create master guide. abort
	Poi.Guide.steps = {}
	Poi.Guide.hidden = true

	for i,guide in pairs(ZGV.registeredguides) do
		if guide.poi then
			if not guide.fully_parsed then
				guide:Parse(true)
			end
			-- copy all steps
			for _,s in pairs(guide.steps) do 
				table.insert(Poi.Guide.steps,s) 
			end
			if coroutine.running() then coroutine.yield() end
		end
	end

	for is,vs in pairs(Poi.Guide.steps) do
		for ig,vg in pairs(vs.goals) do
			if vg.action == "poiname" then
				Poi.OwnedTypes[vs.poitype]=true
				
				if vs.poitype == "treasure" then vg.action = "poi_treasure" end
				if vs.poitype == "rare" then vg.action = "poi_rare" end
				if vs.poitype == "battlepet" then vg.action = "poi_battlepet" end
				if vs.poitype == "achievement" then vg.action = "poi_achievement" end
			end
		end
		if (is%100==0) and coroutine.running() then coroutine.yield() end
	end

	ZGV:SendMessage("ZYGOR_POI_REGISTERED_GUIDE", "done")
end

function Poi:CheckValidity(type,id,subid)
	if ZGV.db.profile.hideguide[type] then
		return false -- poi type hidden
	end

	if type == "battlepet" then
		return not ZGV.PetBattle:HasPetByDisplay(id)
	elseif type=="treasure" or type=="rare" then
		return not ZGV.completedQuests[id]
	elseif type=="achievement" then
		if subid then
			if GetAchievementNumCriteria(id) < subid then -- Causes errors when blizzard changes crap.
				ZGV:Print("POI for %d/%d cannot load - subachive missing.",id,subid)
				return false
			end
			return not (select(3,GetAchievementCriteriaInfo(id,subid)))
		else
			-- full achievement
			local temp = {GetAchievementInfo(id)}
			return not (select(4,GetAchievementInfo(id)))
		end
	else
		return true
	end
end


function Poi:RegisterPoints()
	Poi.Points = {}

	if not Poi.Guide then return end

	local previndex=1

	for i,step in pairs(Poi.Guide.steps) do
		if step.poiname then
			local valid_poi = Poi:CheckValidity(step.poitype,step.poipet or step.poiquest or step.poiachieve,step.poisubachieve)
			if not step:AreRequirementsMet() then valid_poi = false end
			
			if valid_poi then
				Poi.Guide.steps[i].is_returnable = true -- all pois are called with return point set, so mark them as returnable

				if ZGV.Poi.ActivePoiWasFocused and ZGV.Poi.ActivePoiStepNum and ZGV.Poi.ActivePoiStepNum==step.num then
					step.isFocused = true
				end

				local newpoi = {}
				newpoi.name	= step.poiname
				newpoi.access	= step.poiaccess or "Quick"
				--newpoi.accesstime	= step.poiaccesstime
				newpoi.diff	= step.poidiff
				newpoi.level	= step.poilvl
				newpoi.spot	= step.poispot
				newpoi.spot_m	= step.poispot_m
				newpoi.spot_f	= step.poispot_f
				newpoi.spot_x	= step.poispot_x
				newpoi.spot_y	= step.poispot_y
				newpoi.type	= step.poitype
				newpoi.quest	= step.poiquest
				newpoi.currency	= step.poicurrencydata

				newpoi.petlevel = step.poipetlevel
				newpoi.pet	= step.poipet
				if newpoi.pet then Poi.ModelTooltip:SetCreature(newpoi.pet) end -- request model from server

				newpoi.achieve		= step.poiachieve
				newpoi.subachieve	= step.poisubachieve
				newpoi.achievename	= step.poiachievename
				newpoi.subachievename	= step.poisubachievename

				newpoi.npcname	= step.npc

				newpoi.itemdata	= step.poiitemdata
				newpoi.itemid = step.poiitemid
				newpoi.stepstart = i
				newpoi.stepend = i

				local starts_m,starts_x,starts_y = nil,nil,nil
				for ig,goal in pairs(step.goals) do
					if goal.action == "goto" then
						starts_m = goal.map
						starts_f = goal.f or 0
						starts_x = goal.x
						starts_y = goal.y
						break
					end
				end

				if step.waypath then
					local ip,point = next(step.waypath.coords)
					starts_m = point.map
					starts_f = point.f or 0
					starts_x = point.x
					starts_y = point.y
				end

				if starts_m and ZGV.db.profile.poiautodetect then
					newpoi.starts_m = starts_m
					newpoi.starts_f = starts_f
					newpoi.starts_x = starts_x
					newpoi.starts_y = starts_y
				else
					newpoi.starts_m = newpoi.spot_m
					newpoi.starts_f = newpoi.spot_f
					newpoi.starts_x = newpoi.spot_x
					newpoi.starts_y = newpoi.spot_y
				end

				step.starts_m = newpoi.starts_m
				step.starts_f = newpoi.starts_f
				step.starts_x = newpoi.starts_x
				step.starts_y = newpoi.starts_y

				Poi.Points[i] = newpoi

				previndex = i
			else
				ZGV.db.char.ActivatedPois[i] = nil
				previndex = false
			end
		else
			if previndex then
				Poi.Points[previndex].stepend = i
			end
		end
	end

	local function add_goal(data,step,first)
		local newgoal = ZGV.GoalProto:New(data)
		local stored_status
		if data.override_status then stored_status = data.override_status end

		newgoal.parentStep = step
		newgoal.override_status = data.override_status

		if first then
			table.insert(step.goals,1,newgoal)
		else
			step.goals[#step.goals+1] = newgoal
		end
	end

	local function copy_goal(source,target)
		local data = {}
		for i,v in pairs(source) do
			data[i]=v
		end
		data.parentStep = target
		local result = ZGV.GoalProto:New(data)
		result.num = #target.goals+1
		table.insert(target.goals,result)
	end

	for i,target in pairs(Poi.Points) do
		for index=target.stepstart,target.stepend do
		if Poi:CheckValidity(target.type,target.pet or target.quest or target.achieve,target.subachieve) then
			Poi.Guide.steps[index].is_poi = true

			--[[ Future: Multipoi support
			-- poimode 1 : announce
			local poistep = Poi.Guide.steps[target.stepstart]

			local announcestep = ZGV.StepProto:New({})
			for is,vs in pairs(poistep) do announcestep[is] = vs end
			announcestep.goals = {}
			for ig,vg in pairs(poistep.goals) do if ANNOUNCE_POI_FIELDS[vg.action] then copy_goal(vg,announcestep) end end
			announcestep.PoiStep = poistep

			announcestep.num = target.stepstart
			announcestep.is_expanded = false
			Poi.AnnounceSteps[1][index] = announcestep
			--]]

			-- poimode 2 : full step
			local poistep = Poi.Guide.steps[index]

			local announcestep = ZGV.StepProto:New({})
			for is,vs in pairs(poistep) do announcestep[is] = vs end
			announcestep.goals = {}
			for ig,vg in pairs(poistep.goals) do if not FULLSTEP_POI_FIELDS[vg.action] then copy_goal(vg,announcestep) end end
			announcestep.PoiStep = poistep

			announcestep.num = index
			Poi.AnnounceSteps[2][index] = announcestep
		end
		end
	end

	ZGV:SendMessage("ZYGOR_POI_REGISTERED_POINTS", "done")
end

function Poi:RefreshMapIcons()
	for i,point in pairs(ZGV.Pointer.waypoints) do
		if point.poiNum and point.storedData then
			local active = ZGV.db.char.ActivatedPois[point.poiNum] and "_on" or ""	
			point:SetIcon(ZGV.Pointer.Icons[(ZGV.Poi.Points[point.poiNum].type)..active]) 

			if not Poi:CheckValidity(point.storedData.type,point.storedData.pet or point.storedData.quest or point.storedData.achieve,point.storedData.subachieve) then
				ZGV.db.char.ActivatedPois[point.poiNum] = nil
				ZGV.Pointer:RemoveWaypoint(i)
			end
		end
	end
end

function Poi.Waypoint_OnClick(way,button)
	if UnitAffectingCombat("player") then return end

	if button=="LeftButton" then
		-- deactive all current pois
		ZGV.db.char.ActivatedPois = {}
		local currentState = way.waypoint.isActivated
		for i,point in pairs(ZGV.Pointer.pointsets.poi.points) do
			point.isActivated = false
		end

		way.waypoint.isActivated = not currentState
		ZGV.db.char.ActivatedPois[way.waypoint.poiNum]=way.waypoint.isActivated 
		if way.waypoint.isActivated then
			ZGV:SetStepFocus(Poi.AnnounceSteps[2][way.waypoint.poiNum])
			way.waypoint:SetIcon(ZGV.Pointer.Icons[ZGV.Poi.Points[way.waypoint.poiNum].type.."_on"])
		elseif not way.waypoint.isNear then
			ZGV.Poi.Points[way.waypoint.poiNum].is_expanded = false
			way.waypoint:SetIcon(ZGV.Pointer.Icons[ZGV.Poi.Points[way.waypoint.poiNum].type])
		end
		Poi:RefreshMapIcons()
		ZGV:UpdateFrame(true)
	end
end

function Poi.Waypoint_GetTooltipData(way)
	local newpoi = Poi.Points[way.poiNum]

	local tooltipdata = {}
	tooltipdata.ZGV_OPTIONS = {}
	if newpoi.type=="treasure" then	
		table.insert(tooltipdata,"|cffffffffTreasure: "..newpoi.name) 
	end
	if newpoi.type=="rare" then 
		table.insert(tooltipdata,"|cffffffffRare: "..newpoi.name) 
		if newpoi.level-UnitLevel("player")>3 then
			table.insert(tooltipdata,"|cffee0000Warning: This NPC will be hard to solo at your level") 
		end
	end
	if newpoi.type=="battlepet" then 
		table.insert(tooltipdata,"|cffffffffPet: "..newpoi.name) 
		table.insert(tooltipdata,"|cffffffffLevel: "..newpoi.petlevel) 
		if newpoi.level-UnitLevel("player")>3 then
			table.insert(tooltipdata,"|cffee0000Warning: Mobs in this area will be hard to solo at your level") 
		end
		if newpoi.pet then
			tooltipdata.ZGV_OPTIONS.MODEL = newpoi.pet
		end
		if newpoi.achievename then
			table.insert(tooltipdata,"|cffffffffSource: Reward for "..newpoi.achievename)
		elseif newpoi.npcname then
			table.insert(tooltipdata,"|cffffffffSource: Sold by "..newpoi.npcname)
		else
			table.insert(tooltipdata,"|cffffffffSource: Capture")
		end
	end
	if newpoi.type=="achievement" then 
		local achievename = "|cffffffffAchievement: "..newpoi.achievename
		if newpoi.subachievename then
			achievename = achievename.." ("..newpoi.subachievename..")"
		end
		table.insert(tooltipdata,achievename) 
		if newpoi.level-UnitLevel("player")>3 then
			table.insert(tooltipdata,"|cffee0000Warning: Mobs in this area will be hard to solo at your level") 
		end
	end

	--[[
	local trueTime = ZGV.Poi:GetTrueAccessTime(ZGV.Poi.Guide.steps[way.poiNum])
	table.insert(tooltipdata,"|cffffffffEstimated time: "..trueTime) 
	table.insert(tooltipdata,"|cffffffff|r")
	--]]

	local itemtooltip = {}
	if newpoi.itemid then
		table.insert(itemtooltip,"|cffffffffReward:")
		
		for _,itemdata in pairs(newpoi.itemdata) do
			if itemdata.item == "RANDOM" then
				_,_,_,color = GetItemQualityColor(2)
				table.insert(itemtooltip,{text=	((itemdata.value and itemdata.value.." ") or "")..("|c"..(color or "ffffffff")).."Random green"..(tonumber(itemdata.value or 1) > 1 and "s" or ""), icon=ZGV.DIR.."\\Skins\\poirandomgreen"})
			else
				local first_line = #itemtooltip+1
				MyScanningTooltip:SetOwner(UIParent, "ANCHOR_NONE")
				MyScanningTooltip:SetItemByID(itemdata.item)

				local ilvl, minlevel, slot = nil, nil, nil
				local name, link, _, _, _, _, _, _, _, icon = GetItemInfo(itemdata.item)


				for i=1,MyScanningTooltip:NumLines() do
					local toolline=_G["MyScanningTooltipTextLeft"..i] 
					if toolline then
						local skip = false
						local r, g, b, a = toolline:GetTextColor()
						local color = ("|c%02x%02x%02x%02x"):format(a*255,r*255,g*255,b*255)
						local text = toolline:GetText()
						if string.match(text, ITEM_LEVEL_FILTER) then ilvl = string.match(text, ITEM_LEVEL_FILTER) skip = true end -- item level, store for later
						if string.match(text, ITEM_MIN_LEVEL_FILTER) then minlevel = string.match(text, ITEM_MIN_LEVEL_FILTER) skip = true end -- min level, store for later
						if text==ITEM_BIND_ON_PICKUP then skip=true end -- bop info, skip
						for _,STRING in pairs(ITEM_SLOTS_ARRAY) do -- item slot, store for later
							if text==STRING then slot = text skip = true end
						end

						if string.match(text, '"') and color=="|cfefed100" then skip=true end -- flavour text, skip

						if not skip then table.insert(itemtooltip,{text=color..text,indent=true}) end
					end
				end
				local details = nil
				if minlevel then details = (details or "|cffffffff") .. LEVEL.." "..minlevel end
				if ilvl then details = (details or "|cffffffff") .." i"..ilvl end
				if slot then details = (details or "|cffffffff") .." "..slot end

				if itemdata.value then -- if we have info on how many items, attach that to item name
					itemtooltip[first_line].text = itemtooltip[first_line].text.. "|r x "..itemdata.value
				end
				
				if details then table.insert(itemtooltip,first_line+1,{text=details,indent=true}) end
				if icon then itemtooltip[first_line].icon = icon:gsub(".blp","") end
				if not icon then tooltipdata.ZGV_OPTIONS.REFRESH=true end
			end
			table.insert(itemtooltip,"|cffffffff|r")
		end
	end

	local currencytooltip = {}
	if newpoi.currency and #newpoi.currency>0 and (newpoi.type=="treasure" or newpoi.type=="rare") then
		table.insert(currencytooltip,"|cffffffffCurrency:")

		for _,currency in pairs(newpoi.currency) do
			table.insert(currencytooltip,{text="|cffffffff".."|T"..currency.icon..":0|t "..currency.type})
		end
		table.insert(currencytooltip,"|cffffffff|r")
	end
	if newpoi.currency and #newpoi.currency>0 and (newpoi.type=="battlepet") then
		local data = {}

		for _,currency in pairs(newpoi.currency) do
			table.insert(data,"|cffffffff"..(currency.value and currency.value.." " or "").."|T"..currency.icon..":0|t")
		end
		table.insert(currencytooltip,"|cffffffffCost: "..table.concat(data,", ").."|cffffffff|r")
	end

	for i,v in pairs(itemtooltip) do table.insert(tooltipdata,v) end
	for i,v in pairs(currencytooltip) do table.insert(tooltipdata,v) end

	if ZGV.db.char.ActivatedPois[newpoi.stepstart] and not way.isNear then
		table.insert(currencytooltip,"|cffffffff|r")
		table.insert(tooltipdata,"|cffffaa00Click to remove from Guide Viewer|r") 
	else
		table.insert(currencytooltip,"|cffffffff|r")
		table.insert(tooltipdata,"|cffffaa00Click to send to Guide Viewer|r") 
	end

	return tooltipdata
end

function Poi:RegisterWaypoints()
	Poi.Waypoints = {}
	local collectedt = 0
	local collectedr = 0
	Poi.DoneLoadingPoints = false

	for i,poi in pairs(Poi.Points) do
		if (ZGV.db.profile.poitype==1 and poi.access=="Quick") or  -- quick mode
		   (ZGV.db.profile.poitype==2)  -- complete mode, ignore access type
		   then
		if Poi:CheckValidity(poi.type,poi.pet or poi.quest or poi.achieve,poi.subachieve) then -- we do not care about pois that are already completed
			local newway = {}
			newway.map = poi.starts_m
			newway.floor = poi.starts_f or 0
			newway.x = poi.starts_x
			newway.y = poi.starts_y

			newway.title = poi.name


			if ZGV.db.char.ActivatedPois[i] then
				newway.icon = ZGV.Pointer.Icons[poi.type.."_on"]
			else
				newway.icon = ZGV.Pointer.Icons[poi.type]
			end

			if poi.type=="battlepet" and false then
				local species = ZGV.PetBattle.SpeciesByDisplayId[poi.pet]
				if not species then
					print(poi.name,poi.pet,"missing from SpeciesByDisplayId")
				else
					local _,icon = C_PetJournal.GetPetInfoBySpeciesID(species)
					newway.customs = {icon=icon,coords={0,0,0,1,1,0,1,1}}
				end
			end

			--[[	-- POIs one at a time; no point in highlighting "near" POIs.
			newway.OnNear=function(self) 
				if ZGV.Poi.Points[self.poiNum].type=="treasure" then
					self:SetIcon(ZGV.Pointer.Icons.treasure_on) 
				elseif ZGV.Poi.Points[self.poiNum].type=="rare" then
					self:SetIcon(ZGV.Pointer.Icons.rare_on)
				end
			end
			newway.OnFar=function(self) 
				if not self.isActivated then -- do not change icon if poi was manually activated
					ZGV.Poi.Points[self.poiNum].is_expanded = false
					if ZGV.Poi.Points[self.poiNum].type=="treasure" then
						self:SetIcon(ZGV.Pointer.Icons.treasure) 
					elseif ZGV.Poi.Points[self.poiNum].type=="rare" then
						self:SetIcon(ZGV.Pointer.Icons.rare)
					end
				end
			end

			newway.OnUpdate=function(self,elapsed)  --TODO rework this CPU hog
				if not ZGV.Poi.DoneLoadingPoints then return end
				ZGV.Poi.Points[self.poiNum].dist = self.frame_minimap.dist
				if not self.storedData.is_expanded then
					if self.frame_minimap.dist then
						local nowNear = self.frame_minimap.dist<(ZGV.db.profile.poirange or 100)
						if nowNear and not self.isNear then
							self.isNear=true
							self:OnNear()
						elseif not nowNear and self.isNear then
							self.isNear=false
							self:OnFar()
						end
					end
				end
			end
			--]]

			newway.OnClick = ZGV.Poi.Waypoint_OnClick

			newway.tooltipdata = ZGV.Poi.Waypoint_GetTooltipData

			newway.isNear=false
			newway.onminimap = "zone"
			newway.onworldmap = "zone"
			newway.storedData = poi

			newway.poiNum = i
			table.insert(Poi.Waypoints,newway)
			--Poi.Waypoints[i] = newway
		end --/quest
		end --/type
	end

	ZGV:SendMessage("ZYGOR_POI_REGISTERED_WAYS", "done")
end

function Poi:DisplayPois()
	--if not ZGV.DEV then ZGV.Poi.Waypoints={} return end  --devwall
	if not ZGV.Poi.Waypoints then return end
	ZGV.Pointer:ShowSet(
		{
			coords=ZGV.Poi.Waypoints,
			ants=nil
		},
		"poi"
	)
	Poi.DoneLoadingPoints = true
end

function Poi:GetNearPois()
	if not ZGV.db.profile.poienabled then return {} end
	if not ZGV.Pointer.pointsets.poi then return {} end
	--if UnitOnTaxi("player") then return {} end
	if UnitIsGhost("player") then return {} end

	--if not ZGV.DEV then return {} end  --devwall point.subachieve

	local ActivePoiNum = nil

	for i,v in pairs(ZGV.db.char.ActivatedPois) do
		if v and Poi.Points[i] then
			if not Poi:CheckValidity(Poi.Points[i].type,Poi.Points[i].pet or Poi.Points[i].quest or Poi.Points[i].achieve,Poi.Points[i].subachieve) then
				i=nil
				--Poi:RefreshMapIcons()
			else
				ActivePoiNum = i
			end
		end
	end

	if UnitAffectingCombat("player") then
		if not Poi.CachedCombatPoi then
			if not ActivePoiNum then 
				Poi.CachedCombatPoi = {}
			else
				Poi.CachedCombatPoi = {Poi.Points[ActivePoiNum]}
			end
		end
		return Poi.CachedCombatPoi
	else
		Poi.CachedCombatPoi = nil
	end

	if not ActivePoiNum then return {} end
	if not Poi:CheckValidity(Poi.Points[ActivePoiNum].type,Poi.Points[ActivePoiNum].pet or Poi.Points[ActivePoiNum].quest or Poi.Points[ActivePoiNum].achieve,Poi.Points[ActivePoiNum].subachieve) then return {} end

	return {Poi.Points[ActivePoiNum]}

	--[[ point.subachieve
	local nearpois = {}
	local activepois = {}
	local returnpois = {}
	for i,point in pairs(ZGV.Pointer.pointsets.poi.points) do
		--if point.isActivated or ZGV.db.char.ActivatedPois[point.poiNum] or (ZGV.db.profile.poiautodetect and point.isNear) then
		if ZGV.db.char.ActivatedPois[point.poiNum] then
			ZGV.Poi.Guide.steps[point.poiNum].pointerindex = i
			--Poi.Points[point.poiNum].trueTime = Poi:GetTrueAccessTime(ZGV.Poi.Guide.steps[point.poiNum])
			table.insert(returnpois,Poi.Points[point.poiNum])
		end
	end
	
	sort(returnpois,function(a,b)
		if a.is_expanded == b.is_expanded then
			if a.trueTime and b.trueTime then 
				return a.trueTime<b.trueTime 
			else 
				return a.name<b.name 
			end
		else 
			return a.is_expanded
		end
	end)

	debugpois = returnpois
	return returnpois
	--]]
end

function Poi:GetPoisAtPlayer()
	return {}
end

function Poi:GetListOfPois()
	if not ZGV.db.profile.poienabled then return {} end
	if not Poi.DoneLoadingPoints then return {} end

	local nearpois = Poi:GetNearPois()
	local poimode = ZGV.db.profile.poimode or 1
	local poimax = ZGV.db.profile.poimax or 1
	local poisteps = {}
	local poiindex = 1

	if not Poi.Guide then return end

	for nearpoisindex,poi in pairs(nearpois) do
		if poiindex > poimax then
			break -- we are only showing poimax steps
		end

		local announce_index = poi.stepstart

		for index=poi.stepstart,poi.stepend do -- find first not completed poi step
			if not Poi.Guide.steps[index]:IsComplete() then
				announce_index = index
				break
			end
		end

		--[[ Future: Multipoi support
		if Poi.AnnounceSteps[1][announce_index].PoiStep.is_expanded then
			poisteps[poiindex] = Poi.AnnounceSteps[2][announce_index]
		else
			poisteps[poiindex] = Poi.AnnounceSteps[poimode][announce_index]
		end

		poi.is_expanded = Poi.AnnounceSteps[1][announce_index].PoiStep.is_expanded
		--]]
		Poi.Points[announce_index].is_expanded = true
		poisteps[poiindex] = Poi.AnnounceSteps[2][announce_index]
		-- end single poi variant

		poiindex = poiindex + 1
	end

	local prevPoint = Poi.ActivePoiStepNum
	Poi.ActivePoiStepSet = false
	Poi.ActivePoiStepNum = -1
	--ZGV:Debug("&poi Cleared ActivePoiStepSet")


	for _,poi in ipairs(poisteps) do
		if Poi.Points[poi.num].is_expanded then
			--ZGV:Debug("&poi Setting ActivePoiStepSet (#%d, \"%s\")",poi.num,poi.poiname)
			Poi.ActivePoiStepSet = true
			Poi.ActivePoiStep = poi
			Poi.ActivePoiStepNum = poi.num
		end
	end

	if Poi.ActivePoiStepSet and prevPoint ~= Poi.ActivePoiStep.num then 
	-- we have a new active poi, show its goto dots, hide old ones
		ZGV:Debug("&poi We have a new active poi, show its goto dots, hide old ones.")
		--ZGV.Pointer:ClearWaypoints("poigoto") -- sinus: Waypoints:ShowWaypoints now does this.
		--Poi.ActivePoiStepDisplayed = false
		ZGV:ShowWaypoints()
	end
	if Poi.ActivePoiStepSet and prevPoint == Poi.ActivePoiStep.num and not Poi.ActivePoiStepDisplayed then 
	-- prevent setwaypoint called from step focus from readding existing dots
		ZGV:Debug("&poi Poi step displayed.")
		Poi.ActivePoiStepDisplayed = true
	end
		
	if not Poi.ActivePoiStepSet and prevPoint > 0 then
	-- no active poi, hide goto dots and reset waypoint to default
		ZGV:Debug("&poi no active poi, hide goto dots and reset waypoint to default.")
		ZGV.Pointer:ClearWaypoints("poigoto")
		ZGV:ScheduleTimer(function() ZGV:ShowWaypoints() end,0)
	end

	if not Poi.ActivePoiStepSet and (ZGV.CurrentStep and not ZGV.CurrentStep.isFocused) then
	-- no active poi, return focus to main step
		ZGV:SetStepFocus(ZGV.CurrentStep)
	end

	Poi.CurrentPoiSteps = poisteps
	return poisteps
end

function Poi:ChangeState(enable)
	--if not ZGV.DEV then enable=false end  --devwall

	if ZGV.Poi.ActivePoiStep and ZGV.Poi.ActivePoiStep.isFocused then
		ZGV.Poi.ActivePoiWasFocused=true
	end

	if enable then 
		Poi:Thread_RegisterPoiGuide() 
	else
		ZGV.Pointer:ClearSet("poi")
		Poi.Points = {}
	end
end

function Poi:ShowMapButtons()
	if not WorldMapFrame then return end
	if Poi.MapButtonFrame then return end

	--if not ZGV.DEV then return end  --devwall

	Poi.MapButtonFrame = CHAIN(CreateFrame("FRAME","ZygorPoiMapButtonFrame",WorldMapScrollFrame))
		:SetPoint("BOTTOMLEFT",WorldMapScrollFrame,"BOTTOMLEFT",5,-20)
		:SetSize(50,50)
		:SetBackdrop({bgFile="Interface\\Minimap\\MiniMap-TrackingBorder"})--,tile=true, tileSize=50})
		:SetFrameStrata("HIGH")
		:SetFrameLevel(75)
		:Show()
	.__END

	Poi.MapButton = CHAIN(CreateFrame("Button", "ZygorPoiMapButton" , Poi.MapButtonFrame))
		:SetSize(20,20)
		:SetPoint("TOPLEFT", Poi.MapButtonFrame, "TOPLEFT", 5, -5)
		:SetBackdrop({bgFile=ZGV.DIR.."\\Skins\\zglogo-back"})
		:SetNormalTexture(ZGV.DIR.."\\Skins\\zglogo")
		:SetFrameStrata("HIGH")
		:SetFrameLevel(76)
		:SetScript("OnClick", function() Poi:ShowMapMenu() end)
		:Show()
	.__END
	Poi.MapButton:GetNormalTexture():SetTexCoord(0,0,0,1/4 , 1,0,1,1/4)
end

function Poi:GetTrueAccessTime(target)
	-- Leftover from when poiaccess was using time
	local _m, _f, _x, _y = unpack(Astrolabe.LastPlayerPosition)
	dist, x, y = Astrolabe:ComputeDistance(_m, _f, _x, _y, target.starts_m, target.starts_f, target.starts_x, target.starts_y)
	
	spd = LibRover.maxspeedinzone[ZGV.CurrentMapID][1]*7

	local traveltime = math.floor(math.abs((dist or 0)/ spd))
	local completiontime = target.poiaccesstime or 0
	return ZGV.Pointer.FormatTime(traveltime+completiontime)
end


function Poi:ShowMapMenu()
	--if not ZGV.DEV then return end  --devwall

	local self=ZGV.Poi.MapButtonFrame 
	if not self.menu then self.menu = CreateFrame("FRAME",self:GetName().."Menu",self,"UIDropDownMenuTemplate") end
	UIDropDownMenu_SetAnchor(self.menu, 0, 0, "BOTTOMLEFT", self, "BOTTOMRIGHT")
	local menu = {}

	if ZGV.db.profile.poienabled then 
		tinsert(menu,{
				text = L['opt_poidisable'],
				tooltipTitle = L['opt_poidisable'],
				tooltipText = L['opt_poidisable_desc'],
				tooltipOnButton=1,
				func = function() ZGV:SetOption("Poi","poienabled off") ZGV.Poi:ChangeState(false) end,
				notCheckable=0,
			})
	--[[
		tinsert(menu,{
				text = L['opt_poirange'],
				tooltipTitle = L['opt_poirange'],
				tooltipText = L['opt_poirange_desc'],
				hasArrow = true,
				menuList = {
					{ text = L['opt_poirange_50'], checked = function() return (ZGV.db.profile.poirange==50) end, func = function() ZGV.db.profile.poirange=50 end },
					{ text = L['opt_poirange_100'], checked = function() return (ZGV.db.profile.poirange==100) end, func = function() ZGV.db.profile.poirange=100 end },
					{ text = L['opt_poirange_150'], checked = function() return (ZGV.db.profile.poirange==150) end, func = function() ZGV.db.profile.poirange=150 end },
					{ text = L['opt_poirange_200'], checked = function() return (ZGV.db.profile.poirange==200) end, func = function() ZGV.db.profile.poirange=200 end },
					{ text = L['opt_poirange_250'], checked = function() return (ZGV.db.profile.poirange==250) end, func = function() ZGV.db.profile.poirange=250 end },
					{ text = L['opt_poirange_300'], checked = function() return (ZGV.db.profile.poirange==300) end, func = function() ZGV.db.profile.poirange=300 end },
				},
				notCheckable=1,
			})
	--]]

		local poiTypeList = {}
		for i=1,#POI_TYPES do
			local keyword,display = POI_TYPES[i].keyword,POI_TYPES[i].display
			if Poi.OwnedTypes[keyword] then
				tinsert(poiTypeList,
						{ text = display,
						keepShownOnClick=true, 
						checked = function() return not ZGV.db.profile.hideguide[keyword] end, 
						func = function() 
							if ZGV.db.profile.hideguide[keyword] then
								ZGV.db.profile.hideguide[keyword] = nil
							else
								ZGV.db.profile.hideguide[keyword] = true
							end
							ZGV.Poi:ChangeState(true) 
							UIDropDownMenu_Refresh(self.menu) 
						end }
				)
			end
		end

		tinsert(menu,{
				text = L['opt_poishow'],
				tooltipTitle = L['optpoishow_'],
				tooltipText = L['opt_poishow__desc'],
				hasArrow = true,
				menuList = poiTypeList,
				notCheckable=1,
			})


		tinsert(menu,{
				text = L['opt_poitype'],
				tooltipTitle = L['opt_poitype'],
				tooltipText = L['opt_poitype_desc'],
				hasArrow = true,
				menuList = {
					{ text = L['opt_poitype_quick'], 
					keepShownOnClick=true, 
					checked = function() return (ZGV.db.profile.poitype==1) end, 
					func = function() 
						ZGV.db.profile.poitype=1 
						ZGV.Poi:ChangeState(true) 
						UIDropDownMenu_Refresh(self.menu) 
					end },
					{ text = L['opt_poitype_complete'], 
					keepShownOnClick=true, 
					checked = function() return (ZGV.db.profile.poitype==2) end, 
					func = function() 
						ZGV.db.profile.poitype=2 
						ZGV.Poi:ChangeState(true) 
						UIDropDownMenu_Refresh(self.menu) 
					end },
				},
				notCheckable=1,
			})
		tinsert(menu,{
				text = L['opt_poioptions'],
				tooltipTitle = L['opt_poioptions'],
				tooltipText = L['opt_poioptions_desc'],
				tooltipOnButton=1,
				func = function() ZGV:OpenOptions("poi") end,
				notCheckable=0,
			})
	
	else
		tinsert(menu,{
				text = L['opt_poienabled'],
				tooltipTitle = L['opt_poienabled'],
				tooltipText = L['opt_poienabled_desc'],
				tooltipOnButton=1,
				func = function() ZGV:SetOption("Poi","poienabled on") ZGV.Poi:ChangeState(true) end,
				notCheckable=0,
			})
		tinsert(menu,{
				text = L['opt_poioptions'],
				tooltipTitle = L['opt_poioptions'],
				tooltipText = L['opt_poioptions_desc'],
				tooltipOnButton=1,
				func = function() ZGV:OpenOptions("poi") end,
				notCheckable=0,
			})
	end
	
	EasyMenu(menu,self.menu,nil,0,0,"MENU",false)
	UIDropDownMenu_SetWidth(self.menu, 300)
end


function Poi:HideMapButtons()
end

function Poi:Thread_RegisterPoiGuide()
	local thread = coroutine.create(function() Poi:RegisterPoiGuide() end)
	Poi.registration_timer = ZGV:ScheduleRepeatingTimer(function()
		coroutine.resume(thread)
		if coroutine.status(thread)=="dead" then ZGV:CancelTimer(Poi.registration_timer) end
	end,
	0.01)
end

local function EventHandler(self, event, ...)
	if event=="ZYGOR_GUIDES_PARSED" then Poi:Thread_RegisterPoiGuide() end
	if event=="ZYGOR_POI_REGISTERED_GUIDE" then Poi:RegisterPoints() end
	if event=="ZYGOR_POI_REGISTERED_POINTS" then Poi:RegisterWaypoints() end
	if event=="ZYGOR_POI_REGISTERED_WAYS" then Poi:DisplayPois() end
	if ZGV.Poi.ActivePoiStepNum>0 then	
		if event=="QUEST_LOG_UPDATE" 
		or event=="LOOT_READY" 
		or event=="LOOT_CLOSED" 
		or event=="ENCOUNTER_LOOT_RECEIVED" 
		or event=="CHAT_MSG_CURRENCY" then 
			ZGV:ScheduleTimer(function() 
				Poi:RefreshMapIcons() 
				Poi:GetListOfPois()
				ZGV:UpdateFrame(true)
			end,0)
			ZGV:ScheduleTimer(function() 
				Poi:RefreshMapIcons() 
				Poi:GetListOfPois()
				ZGV:UpdateFrame(true)
			end,2)
		end
	end
end

function Poi:CreateModelTooltip()
	Poi.ModelTooltip = CHAIN(CreateFrame("PlayerModel","temp_model",GameTooltip))
        :SetPoint("TOPLEFT",GameTooltip,"BOTTOMLEFT")
        :SetPoint("TOPRIGHT",GameTooltip,"BOTTOMRIGHT")
	:SetHeight(200)
	:SetBackdrop({
	    bgFile="Interface\\Tooltips\\UI-Tooltip-Background",
	    edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",
	    tile = true, 
	    edgeSize=16,--16 
	    tileSize = 16, 
	    insets = { left = 5, right = 5, top = 5, bottom = 5 }
	    })
	:SetBackdropColor(TOOLTIP_DEFAULT_BACKGROUND_COLOR.r, TOOLTIP_DEFAULT_BACKGROUND_COLOR.g, TOOLTIP_DEFAULT_BACKGROUND_COLOR.b)
	:SetBackdropBorderColor(TOOLTIP_DEFAULT_COLOR.r, TOOLTIP_DEFAULT_COLOR.g, TOOLTIP_DEFAULT_COLOR.b)
	:Hide()
	.__END
	function Poi.ModelTooltip:Attach(tooltip)
		Poi.ModelTooltip:SetParent(tooltip)
		Poi.ModelTooltip:SetPoint("TOPLEFT",tooltip,"BOTTOMLEFT")
		Poi.ModelTooltip:SetPoint("TOPRIGHT",tooltip,"BOTTOMRIGHT")
	end

	function Poi.ModelTooltip:DisplayCreature(creatureid)
		Poi.ModelTooltip:SetCreature(creatureid)

		local extra_data = ZygorGuidesViewer.NPCModelsExtra[creatureid]
		if not extra_data then extra_data = {cx=0,cy=0,cz=0,scale=1,camscale=1} end

		Poi.ModelTooltip:SetPosition(extra_data.cx or 0,extra_data.cy or 0,extra_data or 0)
		Poi.ModelTooltip:SetModelScale(extra_data.scale or 1)
	end
end

local function ModelTooltip_ClearTooltipData(tooltip, ...)
	Poi.ModelTooltip:Hide()
end


tinsert(ZGV.startups,{"POI hooks",function(self)
	ZGV.db.char.ActivatedPois = ZGV.db.char.ActivatedPois or {}
	ZGV.db.profile.hideguide = ZGV.db.profile.hideguide or {}
	ZGV:AddMessage("ZYGOR_GUIDES_PARSED",EventHandler)
	ZGV:AddMessage("ZYGOR_POI_REGISTERED_GUIDE",EventHandler)
	ZGV:AddMessage("ZYGOR_POI_REGISTERED_POINTS",EventHandler)
	ZGV:AddMessage("ZYGOR_POI_REGISTERED_WAYS",EventHandler)
	CreateFrame( "GameTooltip", "MyScanningTooltip", nil, "GameTooltipTemplate" )
	Poi.Events = CreateFrame("Frame")
	Poi.Events:RegisterEvent("QUEST_LOG_UPDATE")
	Poi.Events:RegisterEvent("LOOT_READY")
	Poi.Events:RegisterEvent("LOOT_CLOSED")
	Poi.Events:RegisterEvent("CHAT_MSG_CURRENCY")
	Poi.Events:RegisterEvent("ENCOUNTER_LOOT_RECEIVED")
	Poi.Events:SetScript("OnEvent",EventHandler)
	Poi:ShowMapButtons()
	Poi:CreateModelTooltip()
	GameTooltip:HookScript("OnTooltipCleared", ModelTooltip_ClearTooltipData)
	WorldMapTooltip:HookScript("OnTooltipCleared", ModelTooltip_ClearTooltipData)
end})
