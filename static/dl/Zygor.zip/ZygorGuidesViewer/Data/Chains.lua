local ZGV=ZygorGuidesViewer
if not ZGV then return end

-- [11-03-18] removed completely. Fetch from repo if needed.
